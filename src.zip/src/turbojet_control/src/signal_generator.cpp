#include "turbojet_control/signal_generator.hpp"
#include <chrono>
#include <cmath>
#include <functional>
#include <memory>

using namespace std::chrono_literals;

namespace turbojet_control
{

SignalGenerator::SignalGenerator(const rclcpp::NodeOptions & options)
: Node("signal_generator", options)
{
  // Create publisher for throttle signal
  publisher_ = this->create_publisher<std_msgs::msg::UInt16>("throttle_signal", 10);
  
  // Create timer to generate signal at 20Hz (0.05s as in MATLAB)
  timer_ = this->create_wall_timer(
    50ms, std::bind(&SignalGenerator::timer_callback, this));
  
  // Record start time
  start_time_ = this->now();
  
  RCLCPP_INFO(this->get_logger(), "Signal Generator node started");
}

void SignalGenerator::timer_callback()
{
  // Calculate elapsed time in seconds
  auto current_time = this->now();
  double elapsed = (current_time - start_time_).nanoseconds() / 1e9;
  
  // Generate signal based on elapsed time
  uint16_t throttle_value = 0;
  
  if (elapsed < 300 + time_offset_) {
    throttle_value = step_signal(elapsed, time_offset_);
  } else if (elapsed >= 300 + time_offset_ && elapsed < 400 + time_offset_) {
    throttle_value = chirp_oscillate(elapsed, time_offset_);
  } else if (elapsed >= 400 + time_offset_ && elapsed < 405 + time_offset_) {
    throttle_value = horizontal_transition(elapsed, time_offset_);
  } else if (elapsed >= 405 + time_offset_ && elapsed < 505 + time_offset_) {
    throttle_value = ramp_signal(elapsed, time_offset_);
  } else {
    throttle_value = 700; // Constant value after 555s
  }
  
  // Ensure value is within bounds
  throttle_value = std::max(0, std::min(1000, static_cast<int>(throttle_value)));
  
  // Publish the signal
  auto message = std_msgs::msg::UInt16();
  message.data = throttle_value;
  publisher_->publish(message);
  
  RCLCPP_DEBUG(this->get_logger(), "Publishing throttle signal: %d at time: %.2f", 
               throttle_value, elapsed);
}

uint16_t SignalGenerator::step_signal(double t, double time_offset)
{
  double val = 0;
  
  if (t < 15 + time_offset) {
    val = 0;           // Initial value
  } else if (t >= 15 + time_offset && t < 30 + time_offset) {
    val = 200;         // +200
  } else if (t >= 30 + time_offset && t < 45 + time_offset) {
    val = 0;           // -200
  } else if (t >= 45 + time_offset && t < 60 + time_offset) {
    val = 400;         // +400
  } else if (t >= 60 + time_offset && t < 75 + time_offset) {
    val = 0;           // -400
  } else if (t >= 75 + time_offset && t < 90 + time_offset) {
    val = 600;         // +600
  } else if (t >= 90 + time_offset && t < 105 + time_offset) {
    val = 0;           // -600
  } else if (t >= 105 + time_offset && t < 120 + time_offset) {
    val = 800;         // +800
  } else if (t >= 120 + time_offset && t < 135 + time_offset) {
    val = 0;           // -800
  } else if (t >= 135 + time_offset && t < 150 + time_offset) {
    val = 1000;        // +1000
  } else if (t >= 150 + time_offset && t < 165 + time_offset) {
    val = 500;         // -500
  } else if (t >= 165 + time_offset && t < 180 + time_offset) {
    val = 300;         // -200
  } else if (t >= 180 + time_offset && t < 195 + time_offset) {
    val = 800;         // +500
  } else if (t >= 195 + time_offset && t < 210 + time_offset) {
    val = 400;         // -400
  } else if (t >= 210 + time_offset && t < 225 + time_offset) {
    val = 950;         // +550
  } else if (t >= 225 + time_offset && t < 240 + time_offset) {
    val = 150;         // -800
  } else if (t >= 240 + time_offset && t < 255 + time_offset) {
    val = 600;         // +450
  } else if (t >= 255 + time_offset && t < 270 + time_offset) {
    val = 350;         // -250
  } else if (t >= 270 + time_offset && t < 285 + time_offset) {
    val = 320;         // -30
  } else {
    val = 600;         // Final value
  }
  
  // Clamp value between 0 and 1000
  val = std::max(0.0, std::min(1000.0, val));
  return static_cast<uint16_t>(std::round(val));
}

uint16_t SignalGenerator::process_chirp(double chirp_base, double scale)
{
  double scaled = (chirp_base + 1.0) / 2.0 * scale;
  double val = std::round(scaled);
  val = std::max(0.0, std::min(1000.0, val));
  return static_cast<uint16_t>(val);
}

double chirp_impl(double t, double f0, double t1, double f1, const std::string& method)
{
  // Simplified logarithmic chirp implementation
  // In a real implementation, you would use a more accurate chirp function
  double B = f1 - f0;
  double total_time = t1; // Assuming t0 = 0
  
  if (method == "logarithmic") {
    // Simplified log chirp: f(t) = f0 * (f1/f0)^(t/t1)
    // Phase = 2*pi * integral(f(t) dt) = 2*pi * f0 * t1 / ln(f1/f0) * [(f1/f0)^(t/t1) - 1]
    if (f0 > 0 && f1 > 0 && total_time > 0) {
      double ratio = f1 / f0;
      if (ratio != 1.0) {
        double beta = total_time / std::log(ratio);
        double phase = 2 * M_PI * beta * f0 * (std::pow(ratio, t/total_time) - 1.0);
        return std::sin(phase);
      }
    }
  }
  
  // Default to linear chirp if logarithmic fails or is not specified
  double k = B / total_time; // Rate of frequency change
  double phase = 2 * M_PI * (f0 * t + 0.5 * k * t * t);
  return std::sin(phase);
}

uint16_t SignalGenerator::chirp_oscillate(double t, double time_offset)
{
  uint16_t val = 0;
  
  if (t >= 300 + time_offset && t < 345 + time_offset) {
    double chirp_base = chirp_impl(t, 0.000001 * M_PI, 350 + time_offset, 0.2 * M_PI, "logarithmic");
    val = process_chirp(chirp_base, 500) + 450;
  } else if (t >= 345 + time_offset && t < 350 + time_offset) {
    val = 450;
  } else { // 350 <= t < 400
    double chirp_base = chirp_impl(t, 0.000001 * M_PI, 400 + time_offset, 0.2 * M_PI, "logarithmic");
    val = process_chirp(chirp_base, 600) - 50;
  }
  
  return val;
}

uint16_t SignalGenerator::horizontal_transition(double t, double time_offset)
{
  // Constant value of 300
  return 300;
}

uint16_t SignalGenerator::ramp_signal(double t, double time_offset)
{
  double start_t, end_t, start_val, end_val;
  
  if (t >= 405 + time_offset && t < 435 + time_offset) {
    start_t = 405 + time_offset;
    end_t = 435 + time_offset;
    start_val = 300;
    end_val = 1000;
  } else if (t >= 435 + time_offset && t < 475 + time_offset) {
    start_t = 435 + time_offset;
    end_t = 475 + time_offset;
    start_val = 1000;
    end_val = 0;
  } else { // 475 <= t < 505
    start_t = 475 + time_offset;
    end_t = 505 + time_offset;
    start_val = 0;
    end_val = 700;
  }
  
  double slope = (end_val - start_val) / (end_t - start_t);
  double val = start_val + slope * (t - start_t);
  val = std::round(val);
  val = std::max(0.0, std::min(1000.0, val));
  
  return static_cast<uint16_t>(val);
}

}  // namespace turbojet_control

// Main function
int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<turbojet_control::SignalGenerator>());
  rclcpp::shutdown();
  return 0;
}