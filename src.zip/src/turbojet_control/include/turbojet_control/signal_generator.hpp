#ifndef TURBOJET_CONTROL__SIGNAL_GENERATOR_HPP_
#define TURBOJET_CONTROL__SIGNAL_GENERATOR_HPP_

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/u_int16.hpp"

namespace turbojet_control
{

class SignalGenerator : public rclcpp::Node
{
public:
  explicit SignalGenerator(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  void timer_callback();
  
  // Step signal function
  uint16_t step_signal(double t, double time_offset);
  
  // Chirp oscillate function
  uint16_t chirp_oscillate(double t, double time_offset);
  
  // Horizontal transition function
  uint16_t horizontal_transition(double t, double time_offset);
  
  // Ramp signal function
  uint16_t ramp_signal(double t, double time_offset);
  
  // Process chirp helper
  uint16_t process_chirp(double chirp_base, double scale);

  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<std_msgs::msg::UInt16>::SharedPtr publisher_;
  rclcpp::Time start_time_;
  double time_offset_ = 120.0; // Time offset as in MATLAB code
};

}  // namespace turbojet_control

#endif  // TURBOJET_CONTROL__SIGNAL_GENERATOR_HPP_